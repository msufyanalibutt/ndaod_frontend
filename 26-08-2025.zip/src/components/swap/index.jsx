import React, { useState, useEffect } from "react";
import { Row, Col, Container, Form, FormGroup, Spinner } from "react-bootstrap";
import SellSwap from "./sell";
import BuySwap from "./buy";
import axios from "axios";
import { networks } from "../../utils/networks";
import { useFormik } from "formik";
import * as yup from "yup";
import { useWeb3React } from "@web3-react/core";
import { WALLETCONTEXT } from "../../contexts/walletContext";
import { constants, ethers } from "ethers";
import Toastify from "../toast";
import { useNavigate } from "react-router-dom";
import { FiArrowDown } from "react-icons/fi";

const Index = ({ senderAddress, searchParams }) => {
  const navigate = useNavigate();
  const { chainId, account } = useWeb3React();
  const { getCustomContract, getSwapContract } = WALLETCONTEXT();
  const [loading, setLoading] = useState(false);
  const [tokens, setTokens] = useState([]);

  const [toAddress, setToAddress] = useState(null);
  const [fromAddress, setFromAddress] = useState(null);
  const [approved, setApproved] = useState(false);
  const [maxBalance, setMaxBalance] = useState(0);
  const [data, setData] = useState(null);
  useEffect(() => {
    if (chainId) {
      getTokens();
    }
  }, [chainId]);
  useEffect(() => {
    const tokenAddress = searchParams.get("tokenAddress");
    if (tokenAddress) {
      setFromAddress(tokenAddress);
    } else {
      setFromAddress(networks[chainId].inchCoin);
    }
  }, []);
  useEffect(() => {
    if (fromAddress && account) {
      getInfo();
    }
  }, [fromAddress, senderAddress, toAddress]);
  useEffect(() => {
    if (chainId) {
      setToAddress(networks[chainId].inchUsdt);
    }
  }, [chainId]);
  useEffect(() => {
    if (fromAddress && chainId) {
      ApproveFromAddress();
    }
  }, [fromAddress, chainId]);
  useEffect(() => {
    if (fromAddress || toAddress) {
      getConversionRate(values.fromBalance, { decimals: values.fromdecimals });
    }
  }, [fromAddress, toAddress]);
  const ApproveFromAddress = async () => {
    // try {
    //   let url = `https://api.1inch.io/v4.0/${chainId}/approve/transaction/?amount=115792089237316195423570985008687907853269984665640564039457584007913129639935&tokenAddress=${fromAddress}`;
    //   await axios.get(url);
    // } catch (error) {}
    getInfo();
  };
  const getInfo = async () => {
    try {
      if (fromAddress === networks[chainId].inchCoin) {
        setApproved(true);
        return;
      }
      if (!senderAddress) {
        return;
      }
      setLoading(true);
      const contract = await getCustomContract(fromAddress);
      let allowance = await contract.allowance(
        senderAddress,
        networks[chainId].inch
      );
      allowance = String(allowance);
      if (allowance > 0) {
        setApproved(true);
      } else {
        setApproved(false);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };
  const getTokens = async () => {
    try {
      const result = await axios.get(
        `https://open-api.openocean.finance/v4/${networks[chainId].chainName}/tokenList`
      );
      setTokens(result.data.data);
    } catch (error) {}
  };

  const replaceAddresses = () => {
    let from = fromAddress;
    let to = toAddress;
    setFromAddress(to);
    setToAddress(from);
    // setFieldValue("toBalance",values.fromBalance);
    setFieldValue("todecimals",values.fromdecimals);
    // setFieldValue("fromBalance",values.toBalance);
    setFieldValue("fromdecimals",values.todecimals);
    // getConversionRate(values.fromBalance, { decimals: values.fromdecimals });
  };
  const getConversionRate = async (value, item) => {
    if (!value || value < 0) {
      setFieldValue("toBalance", 0);
      return;
    } else {
      // if (value === values.fromBalance) return;
      try {
        let amount = value * Math.pow(10, item.decimals);
        amount = amount.toLocaleString("fullwide", { useGrouping: false });
        let url = `https://open-api.openocean.finance/v4/${networks[chainId].chainName}/quote?inTokenAddress=${fromAddress}&outTokenAddress=${toAddress}&amountDecimals=${amount}&gasPriceDecimals=1000000000`;
        let result = await axios.get(url);

        let quoteDecimals = ethers.utils.formatUnits(
          result.data?.data?.outAmount || 0,
          result.data?.data?.outToken?.decimals
        );
        setFieldValue("toBalance", Number(quoteDecimals).toFixed(2));
        url = `https://open-api.openocean.finance/v4/${networks[chainId].chainName}/swap?fromAddress=${senderAddress}&inTokenAddress=${fromAddress}&outTokenAddress=${toAddress}&amountDecimals=${amount}&slippage=1&gasPriceDecimals=1000000000&account=${senderAddress}`;
        result = await axios.get(url);
        let data = result.data.data;
        setData(data.data);
      } catch (error) {}
    }
  };
  const handleFormSubmit = async (body) => {
    if (!data) return;
    try {
      const swapABI = [
        "function swap(address caller, (address srcToken, address dstToken, address srcReceiver, address dstReceiver, uint256 amount, uint256 minReturnAmount, uint256 guaranteedAmount, uint256 flags, address referrer, bytes permit) desc, (uint256 target, uint256 gasLimit, uint256 value, bytes data)[] calls) payable returns (uint256 returnAmount)",
      ];
      const iface = new ethers.utils.Interface(swapABI);
      let result = iface.decodeFunctionData("swap", data);
      let swapped = result[1];
      if (senderAddress !== account) {
        let bew = createForIface(result[0], swapped, result[2]);
        moveToSwapToken(
          bew,
          networks[chainId].inchCoin === fromAddress ? swapped.amount : 0
        );
        return;
      }
      setLoading(true);
      const contract = await getSwapContract(networks[chainId].inch);
      let value =
        networks[chainId].inchCoin === fromAddress ? swapped.amount : 0;
      result = await contract.swap(result[0], swapped, result[2], {
        value: value,
      });
      await result.wait();
      Toastify("success", "Successfully Swap!");
      resetFields();
    } catch (error) {
      Toastify("error", error.message);
    } finally {
      setLoading(false);
    }
  };
  const formSchema = yup.object().shape({
    fromBalance: yup
      .number()
      .moreThan(0, "Must be more then 0")
      .test(
        "maxLength",
        `You must have enough ${networks[chainId].nativeCurrency.symbol} in addition to the amount to pay for gas`,
        function (value) {
          if (
            value === maxBalance &&
            fromAddress === networks[chainId].inchCoin
          ) {
            return false;
          } else {
            return true;
          }
        }
      )
      .test("maxLength", "Amount exceeds balance", function (value) {
        if (maxBalance === 0 || value > maxBalance) {
          return false;
        } else {
          return true;
        }
      })
      .required("This is required"),
    toBalance: yup
      .number()
      .moreThan(0, "Must be more then 0")
      .required("This is required"),
  });
  const {
    values,
    errors,
    touched,
    handleBlur,
    handleChange,
    handleSubmit,
    isValid,
    dirty,
    setFieldValue,
    resetForm,
  } = useFormik({
    onSubmit: handleFormSubmit,
    initialValues: {
      fromBalance: 0,
      toBalance: 0,
      fromName: "",
      toName: "",
      todecimals: 0,
      fromdecimals: 0,
    },
    validationSchema: formSchema,
  });
  const addToken = async () => {
    try {
      setLoading(true);
      let value = constants.MaxUint256;
      if (senderAddress !== account) {
        moveToApprovedToken();
        return;
      }
      let contract = await getCustomContract(fromAddress);
      let result = await contract.approve(networks[chainId].inch, value);
      await result.wait();
      setLoading(false);
      getInfo();
    } catch (error) {
      Toastify("error", error.message);
      setLoading(false);
    }
  };
  const moveToApprovedToken = () => {
    let value = constants.MaxInt256;
    value = String(value);
    value = value.toLocaleString("fullwide", { useGrouping: false });
    navigate(
      `/approvedToken/${senderAddress}?targetAddress=${networks[chainId].inch}&tokenAddress=${fromAddress}&tokenAmount=${value}`,
      { replace: true }
    );
  };
  const resetFields = () => {
    resetForm();
  };
  const moveToSwapToken = async (bew, value) => {
    const { fromName, toName, fromBalance, toBalance } = values;
    navigate(
      `/customTransaction/${senderAddress}?targetAddress=${networks[chainId].inch}&data=${bew}&value=${value}&title=1inch: Swap ${fromName} to ${toName}&desc=Swap ${fromBalance} ${fromName} to ${toBalance} ${toName}`
    );
  };
  const createForIface = (caller, desc, bew) => {
    let ABI = [
      "function swap(address caller, (address srcToken, address dstToken, address srcReceiver, address dstReceiver, uint256 amount, uint256 minReturnAmount, uint256 guaranteedAmount, uint256 flags, address referrer, bytes permit) desc, (uint256 target, uint256 gasLimit, uint256 value, bytes data)[] calls) payable returns (uint256 returnAmount)",
    ];
    let iface = new ethers.utils.Interface(ABI);
    iface = iface.encodeFunctionData("swap", [caller, desc, bew]);
    return iface;
  };
  return (
    <>
      <Container>
        <Form onSubmit={handleSubmit}>
          <FormGroup className="mb-3">
            <Row>
              <Col xs={12} xl={9} className="mx-auto text-white">
                <h4>Swap</h4>
                <SellSwap
                  tokens={tokens}
                  senderAddress={senderAddress}
                  tokenAddress={fromAddress}
                  setTokenAddress={setFromAddress}
                  searchParams={searchParams}
                  values={values}
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                  handleChange={handleChange}
                  handleSubmit={handleSubmit}
                  setFieldValue={setFieldValue}
                  getConversionRate={getConversionRate}
                  maxBalance={maxBalance}
                  setMaxBalance={setMaxBalance}
                />
                <div className="my-5 d-flex justify-content-center align-items-center">
                  <div
                    className="pointer replace-circle"
                    onClick={replaceAddresses}
                  >
                    <FiArrowDown className="replaceicon" fontSize={"24px"} />
                  </div>
                </div>
                <BuySwap
                  tokens={tokens}
                  senderAddress={senderAddress}
                  tokenAddress={toAddress}
                  setTokenAddress={setToAddress}
                  searchParams={searchParams}
                  values={values}
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                  handleChange={handleChange}
                  handleSubmit={handleSubmit}
                  setFieldValue={setFieldValue}
                />
              </Col>
            </Row>
          </FormGroup>
          <Row>
            <Col xs={12} xl={9} className="mx-auto text-white">
              <FormGroup className="text-white">
                <Row>
                  <Col>
                    <p className="p-0 m-0">Rate:</p>
                  </Col>
                  <Col className="text-right">
                    <div className="p-0 m-0">
                      {values.toBalance > 0 && values.fromBalance > 0
                        ? `1 ${values.fromName} = ${Number(
                            values.toBalance / values.fromBalance
                          ).toFixed(4)} ${values.toName}`
                        : "Insert token amount to see rate"}
                    </div>
                  </Col>
                </Row>
              </FormGroup>
              <FormGroup className="mb-3 text-white">
                <Row>
                  <Col>
                    <p className="p-0 m-0">Slippage:</p>
                  </Col>
                  <Col className="text-right">
                    <p className="p-0 m-0">1%</p>
                  </Col>
                </Row>
              </FormGroup>
              {approved ? (
                <FormGroup className="mb-5">
                  <button
                    type="submit"
                    className="dao-btn w-100"
                    style={{
                      backgroundColor: "#8AB5FF",
                      color: "#0D0D15",
                      fontSize: "20px",
                      fontWeight: "bold",
                    }}
                    disabled={
                      !(isValid && dirty && senderAddress) ||
                      loading ||
                      fromAddress === toAddress
                    }
                  >
                    {loading ? (
                      <Spinner animation="border" variant="primary" />
                    ) : (
                      "Swap"
                    )}
                  </button>
                </FormGroup>
              ) : (
                <FormGroup className="my-3">
                  <button
                    type="button"
                    className="dao-btn w-100"
                    style={{
                      backgroundColor: "#8AB5FF",
                      color: "#0D0D15",
                      fontSize: "20px",
                      fontWeight: "bold",
                    }}
                    disabled={loading}
                    onClick={addToken}
                  >
                    {loading ? (
                      <Spinner animation="border" variant="primary" />
                    ) : (
                      "Approved"
                    )}
                  </button>
                </FormGroup>
              )}
            </Col>
          </Row>
        </Form>
      </Container>
    </>
  );
};

export default Index;
